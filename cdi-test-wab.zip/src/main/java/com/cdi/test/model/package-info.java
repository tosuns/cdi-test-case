@XmlSchema(namespace = "http://www.cdi.com/xml/schema",
           elementFormDefault = XmlNsForm.QUALIFIED,
           xmlns = {@XmlNs(namespaceURI = "http://www.cdi.com/xml/schema",
                           prefix = "")})
package com.cdi.test.model;

import javax.xml.bind.annotation.*;
